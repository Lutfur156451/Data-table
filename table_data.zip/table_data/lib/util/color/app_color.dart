import 'package:flutter/material.dart';

class AppColor {
  static const primaryColor = Color(0xFF10AB83);
  static const secondaryHeaderColor = Color(0xFFC9ECE3);
  static const backgroundColor = Color(0xFFD4D4D4);

}