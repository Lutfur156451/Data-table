import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class AppStyle {
  TextStyle BtnTextStyle = TextStyle(color: Colors.white);

  Divider DividerStyle = Divider(
    thickness: 0.5,
    color: Colors.grey.withOpacity(0.6),
  );
}
