
class AppConstants {
  static const String APP_TITLE = 'Table Data';

}