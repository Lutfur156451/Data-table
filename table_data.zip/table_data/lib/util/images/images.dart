class Images {
  static const String ADD = 'assets/images/add.png';
  static const String MONEY_ICON_BLACK = 'assets/images/taka_black.png';
  static const String MONEY_ICON_COLOR = 'assets/images/taka_color.png';
  static const String MENU = 'assets/images/menu.png';
  static const String SHAP = 'assets/images/shap.png';
}
